package HW_4.Task_2.server;

public class Main {
    public static void main(String[] args) {
        new Server();
    }
}
package HW_4.Task_2.client;

public interface Callback {
    void callback(Object... args);
}